function drawRectangle(y, x, w, h, lbl, iter) {
  var box = $(".box").clone();
  box.find(".box_label").text(lbl);
  box.addClass("cl" + iter);
  box.css("display", "block");
  box.css("right", x);
  box.css("top", y);
  box.css("width", w);
  box.css("height", h);
  $(".real_time").append(box);
}
var yolo_rt;
var iter = 0;
var time_start;
var time_end;
var doLoop = true;
function showPythonProject() {
  fetch('/run_python_project', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({}),
  })
    .then(response => response.json())
    .then(data => {
      console.log('Python project is running:', data);
    })
    .catch(error => {
      console.error('Error running Python project:', error);
    });
}

